document.addEventListener('DOMContentLoaded', function() {
  // DOM Elements
  const userInput = document.getElementById('userInput');
  const sendBtn = document.getElementById('sendBtn');
  const micBtn = document.getElementById('micBtn');
  const chatMessages = document.getElementById('chatMessages');
  const toggleThemeBtn = document.getElementById('toggleTheme');
  const settingsBtn = document.getElementById('settingsBtn');
  const settingsModal = document.getElementById('settingsModal');
  const closeModal = document.querySelector('.close');
  const featureItems = document.querySelectorAll('.features-sidebar li');

  // Theme management
  function toggleTheme() {
    document.body.classList.toggle('dark-theme');
    const isDarkTheme = document.body.classList.contains('dark-theme');
    toggleThemeBtn.innerHTML = isDarkTheme ? '<i class="fas fa-sun"></i>' : '<i class="fas fa-moon"></i>';
    localStorage.setItem('theme', isDarkTheme ? 'dark' : 'light');
  }

  // Check for saved theme preference
  if (localStorage.getItem('theme') === 'dark') {
    document.body.classList.add('dark-theme');
    toggleThemeBtn.innerHTML = '<i class="fas fa-sun"></i>';
  }

  // Settings modal management
  function openSettingsModal() {
    settingsModal.style.display = 'block';
  }

  function closeSettingsModal() {
    settingsModal.style.display = 'none';
  }

  // Feature selection
  function selectFeature(feature) {
    featureItems.forEach(item => item.classList.remove('active'));
    this.classList.add('active');
    const featureName = this.getAttribute('data-feature');
    let suggestion = '';

    switch(featureName) {
      case 'quran':
        suggestion = "You can ask me to recite a specific Surah or Ayah, or search for topics in the Quran.";
        break;
      case 'hadith':
        suggestion = "I can help you find Hadiths from various collections like Bukhari, Muslim, etc.";
        break;
      case 'prayer':
        suggestion = "I can show you prayer times for your location or explain prayer methods.";
        break;
      case 'zakat':
        suggestion = "I can help calculate your Zakat or explain Zakat rules.";
        break;
      case 'hajj':
        suggestion = "I can guide you through Hajj and Umrah rituals and requirements.";
        break;
      case 'islamic-finance':
        suggestion = "Ask me about halal investments, avoiding riba, or Islamic business principles.";
        break;
      case 'parenting':
        suggestion = "I can provide Islamic guidance on raising children and family matters.";
        break;
      case 'art':
        suggestion = "I can show you Islamic calligraphy, patterns, and artistic traditions.";
        break;
      case 'media':
        suggestion = "I can recommend Islamic lectures, podcasts, and videos.";
        break;
      case 'books':
        suggestion = "I can suggest Islamic books on various topics.";
        break;
      case 'counselling':
        suggestion = "I can provide Islamic perspective on mental health and personal issues.";
        break;
      case 'games':
        suggestion = "I can suggest Islamic games and quizzes to test your knowledge.";
        break;
      default:
        suggestion = "How can I help you with this topic?";
    }

    addMessage(suggestion);
  }

  let isRecording = false;

  // Function to add a message to the chat
  function addMessage(message, isUser = false) {
    const messagesDiv = document.getElementById('chatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = isUser ? 'message user-message' : 'message bot-message';

    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';

    // Format message with proper HTML
    if (isUser) {
      const messagePara = document.createElement('p');
      messagePara.textContent = message;
      contentDiv.appendChild(messagePara);
    } else {
      // For bot messages, we allow HTML content for formatting
      contentDiv.innerHTML = `<p>${message.replace(/\n/g, '<br>')}</p>`;
    }

    messageDiv.appendChild(contentDiv);
    messagesDiv.appendChild(messageDiv);

    // Scroll to the bottom
    messagesDiv.scrollTop = messagesDiv.scrollHeight;
  }

  // Function to send a message to the server
  async function sendMessage(message) {
    if (!message.trim()) return;
    addMessage(message, true);
    userInput.value = '';
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message typing';
    typingDiv.innerHTML = '<div class="message-content"><p>Typing<span class="dot">.</span><span class="dot">.</span><span class="dot">.</span></p></div>';
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ message })
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      chatMessages.removeChild(typingDiv);
      addMessage(data.response || "I'm sorry, I couldn't process your request.");
    } catch (error) {
      console.error('Error:', error);
      chatMessages.removeChild(typingDiv);
      addMessage("I'm sorry, I encountered an error. Please try again later.");
    }
  }

  // Speech recognition setup
  let recognition;
  try {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'en-US';

    recognition.onresult = function(event) {
      const transcript = event.results[0][0].transcript;
      userInput.value = transcript;
    };

    recognition.onend = function() {
      micBtn.innerHTML = '<i class="fas fa-microphone"></i>';
      micBtn.classList.remove('recording');
    };

    recognition.onerror = function(event) {
      console.error('Speech recognition error', event.error);
      micBtn.innerHTML = '<i class="fas fa-microphone"></i>';
      micBtn.classList.remove('recording');
      addMessage("I couldn't hear you clearly. Please try again or type your message.");
    };
  } catch (e) {
    console.error('Speech recognition not supported', e);
    micBtn.style.display = 'none';
  }

  function toggleSpeechRecognition() {
    if (micBtn.classList.contains('recording')) {
      recognition.stop();
    } else {
      try {
        recognition.start();
        micBtn.innerHTML = '<i class="fas fa-stop"></i>';
        micBtn.classList.add('recording');
      } catch (e) {
        console.error('Speech recognition error', e);
      }
    }
  }

  // Event listeners
  sendBtn.addEventListener('click', () => sendMessage(userInput.value));
  userInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      sendMessage(userInput.value);
    }
  });
  micBtn.addEventListener('click', toggleSpeechRecognition);
  toggleThemeBtn.addEventListener('click', toggleTheme);
  settingsBtn.addEventListener('click', openSettingsModal);
  closeModal.addEventListener('click', closeSettingsModal);
  window.addEventListener('click', (e) => {
    if (e.target === settingsModal) {
      closeSettingsModal();
    }
  });
  featureItems.forEach(item => {
    item.addEventListener('click', selectFeature);
  });

  const style = document.createElement('style');
  style.textContent = `
    @keyframes ellipsis {
      0% { opacity: 0; }
      50% { opacity: 1; }
      100% { opacity: 0; }
    }
    .typing .dot {
      animation: ellipsis 1s infinite;
      animation-delay: calc(var(--i) * 0.2s);
    }
    .features-sidebar li.active {
      background-color: var(--bot-msg-bg);
      font-weight: bold;
    }
    .recording {
      background-color: #f44336 !important;
      animation: pulse 1.5s infinite;
    }
    @keyframes pulse {
      0% { transform: scale(1); }
      50% { transform: scale(1.1); }
      100% { transform: scale(1); }
    }
  `;
  document.head.appendChild(style);
});