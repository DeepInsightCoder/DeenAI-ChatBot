
import os
import logging
import requests
import json
from typing import Dict, Optional, Any

class AIService:
    """Service to handle interactions with external AI models like OpenAI or DeepSeek"""
    
    def __init__(self):
        self.openai_api_key = os.environ.get("OPENAI_API_KEY", "")
        self.deepseek_api_key = os.environ.get("DEEPSEEK_API_KEY", "")
        self.api_choice = os.environ.get("AI_API_CHOICE", "openai")  # Default to OpenAI
        
        # System prompt to guide the AI in Islamic responses
        self.system_prompt = """
        You are DeenAI, an Islamic knowledge assistant designed to provide accurate and respectful 
        information about Islam. Your responses should be scholarly, nuanced, and backed by 
        Islamic sources where possible. Always maintain an appropriate, respectful tone when 
        discussing religious matters. Please include relevant Quranic verses or Hadith when applicable.
        """
        
    def get_api_response(self, query: str) -> Optional[str]:
        """Get a response from the selected AI API based on the query"""
        if self.api_choice.lower() == "openai":
            return self._get_openai_response(query)
        elif self.api_choice.lower() == "deepseek":
            return self._get_deepseek_response(query)
        else:
            logging.error(f"Unknown API choice: {self.api_choice}")
            return None
            
    def _get_openai_response(self, query: str) -> Optional[str]:
        """Get a response from OpenAI API"""
        if not self.openai_api_key:
            logging.error("OpenAI API key not found")
            return None
            
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.openai_api_key}"
            }
            
            payload = {
                "model": "gpt-3.5-turbo",  # or gpt-4 if available
                "messages": [
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": query}
                ],
                "temperature": 0.7,
                "max_tokens": 800
            }
            
            response = requests.post(
                "https://api.openai.com/v1/chat/completions",
                headers=headers,
                json=payload
            )
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            else:
                logging.error(f"OpenAI API error: {response.status_code}, {response.text}")
                return None
                
        except Exception as e:
            logging.error(f"Error in OpenAI API call: {str(e)}")
            return None
            
    def _get_deepseek_response(self, query: str) -> Optional[str]:
        """Get a response from DeepSeek API using V3 model"""
        if not self.deepseek_api_key:
            logging.error("DeepSeek API key not found")
            return None
            
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.deepseek_api_key}"
            }
            
            payload = {
                "model": "deepseek-chat-v3",  # Updated to V3
                "messages": [
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": query}
                ],
                "temperature": 0.7,
                "max_tokens": 1000,
                "top_p": 0.95
            }
            
        try:
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.deepseek_api_key}"
            }
            
            payload = {
                "model": "deepseek-chat",
                "messages": [
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": query}
                ],
                "temperature": 0.7,
                "max_tokens": 800
            }
            
            # DeepSeek API endpoint (update this with the actual endpoint)
            response = requests.post(
                "https://api.deepseek.com/v1/chat/completions",
                headers=headers,
                json=payload
            )
            
            if response.status_code == 200:
                result = response.json()
                return result["choices"][0]["message"]["content"]
            else:
                logging.error(f"DeepSeek API error: {response.status_code}, {response.text}")
                return None
                
        except Exception as e:
            logging.error(f"Error in DeepSeek API call: {str(e)}")
            return None
