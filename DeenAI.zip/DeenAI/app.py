
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import os
import sys
import json
import traceback

app = Flask(__name__, static_folder='client')
CORS(app)  # Enable CORS for all routes

# Add the current directory to the Python path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

try:
    from islamic_bot.main import IslamicChatbot
    chatbot = IslamicChatbot()
    print("Successfully initialized IslamicChatbot")
except ImportError as e:
    print(f"Error importing IslamicChatbot: {e}")
    traceback.print_exc()
    chatbot = None

@app.route('/')
def home():
    return send_from_directory('client', 'index.html')

@app.route('/<path:path>')
def static_files(path):
    return send_from_directory('client', path)

@app.route('/api/chat', methods=['POST'])
def chat():
    try:
        data = request.get_json()
        if not data or 'message' not in data:
            return jsonify({'error': 'Message is required'}), 400
        
        message = data['message']
        print(f"Received message: {message}")
        
        if not chatbot:
            return jsonify({'error': 'Chatbot not initialized'}), 500
        
        # First attempt to process with built-in logic
        result = chatbot.process_input(message)
        
        # If the chatbot processed it successfully but didn't return a response
        if result is True:
            # Try to get a more detailed response from AI services
            try:
                from islamic_bot.ai_service import AIService
                ai_service = AIService()
                ai_response = ai_service.get_api_response(message)
                if ai_response:
                    response = ai_response
                else:
                    response = "I've processed your request. You can ask another question."
            except Exception as e:
                print(f"Error with AI service: {str(e)}")
                response = "I've processed your request. You can ask another question."
        else:
            # Get a fallback response from the chatbot's knowledge base
            try:
                response = "I'm sorry, I couldn't process that request properly. Let me try to help with what I know."
                # Try to get a general response from knowledge base
                from islamic_bot.knowledge import IslamicKnowledge
                knowledge = IslamicKnowledge()
                knowledge_response = knowledge.get_general_response(message)
                if knowledge_response:
                    response = knowledge_response
            except Exception as e:
                print(f"Error with fallback knowledge response: {str(e)}")
                response = "I'm sorry, I couldn't process that request. Please try asking in a different way."
            
        return jsonify({'response': response})
    except Exception as e:
        print(f"Error in chat endpoint: {str(e)}")
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)
