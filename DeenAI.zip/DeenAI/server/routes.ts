import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

export async function registerRoutes(app: Express): Promise<Server> {
  // put application routes here
  // prefix all routes with /api

  // use storage to perform CRUD operations on the storage interface
  // e.g. storage.insertUser(user) or storage.getUserByUsername(username)

  const httpServer = createServer(app);

  return httpServer;
}
import { Router } from 'express';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);
import axios from 'axios';
const router = Router();

router.post('/api/chat', async (req, res) => {
  try {
    const { message } = req.body;
    
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    // Forward the request to the Flask app
    const response = await axios.post('http://0.0.0.0:5000/api/chat', {
      message
    });

    return res.json(response.data);
  } catch (error) {
    console.error('Error handling chat request:', error);
    return res.status(500).json({ 
      error: 'Internal server error',
      response: "I'm sorry, I couldn't process your request. Please try again later." 
    });
  }
});

export default router;
